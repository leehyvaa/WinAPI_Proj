#include "pch.h"
#include "GObject.h"

GObject::GObject()
{
}


GObject::~GObject()
{
}

void GObject::Update()
{
}

void GObject::Draw()
{
}

bool GObject::Collision(GObject& _vObj)
{
	return false;
}

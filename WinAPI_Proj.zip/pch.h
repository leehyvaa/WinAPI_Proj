#pragma once
#include <Windows.h>
#include <iostream>
#include <string>

#include <vector>
#include <cMath>
#include <tchar.h>
using namespace std;


#include "define.h"
#include "struct.h"
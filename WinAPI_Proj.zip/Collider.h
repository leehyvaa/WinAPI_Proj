#pragma once
#include "CObject.h"
class Collider
{
private:
	CObject* oner;
	int type;
	float radius;
	
};


#pragma once
#include "Vec2.h"

class CTool
{
	SINGLE(CTool)
	

public:
	float LengthPts(Vec2 pt1, Vec2 pt2);



};


